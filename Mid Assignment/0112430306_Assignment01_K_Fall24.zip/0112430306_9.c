#include <stdio.h>
#include <stdbool.h>

int main ()
{
    double x = 3.14;
    printf("The double value: %e\n", x);
    //using e% format specifier to print scientific notation e

    bool e = true;
    printf("The boolean value: %d", e);
    return 0;
}
