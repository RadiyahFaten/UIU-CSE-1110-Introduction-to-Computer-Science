#include <stdio.h>
  int main ()
{
    const float PI = 3.14;
    //PI = 6.34; if I put any other value on PI now it will show error.
     printf("The value of PI: %0.2f", PI);
    return 0;
}
