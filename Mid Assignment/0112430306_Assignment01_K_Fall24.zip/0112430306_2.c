#include <stdio.h>
 int main()

 {
     printf("Hello World.");
     printf("\nThis is my first program.        C is fun.");
     return 0;

 }
