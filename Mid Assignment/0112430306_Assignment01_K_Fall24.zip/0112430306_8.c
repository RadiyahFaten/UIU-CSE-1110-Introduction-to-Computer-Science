#include <stdio.h>

int main ()
{
    int x,y,z;
    scanf("%d %d %d", &x, &y, &z);
    printf("First Value:%d\n",x);
    printf("Last Value: %d",z);
    return 0;


}
