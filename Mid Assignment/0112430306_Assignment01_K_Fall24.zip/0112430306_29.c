#include <stdio.h>
#include <math.h>
int main()
{
    int A, B;
    float x, C;
    printf("Enter the value of x: ");
    scanf("%f", &x);
     A = ceil(x);
    B = floor(x);
    C = fabs(x);
    printf("A = %d, B = %d, C = %f", A, B, C);




}
