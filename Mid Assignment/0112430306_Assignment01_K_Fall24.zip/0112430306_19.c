#include <stdio.h>
int main()
{
    int x;
    printf("Value of X:");
    scanf("%d", &x);
    printf("X++ : %d\n", x++);
    printf("++X : %d\n", ++x);
    printf("X-- : %d\n", x--);
    printf("--X : %d", --x);
    return 0;
}
