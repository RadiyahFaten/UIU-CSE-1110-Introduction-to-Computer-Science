#include <stdio.h>

int main ()
{
    printf("The question is-\"How to write a \\comment/ in C programming language?\"" );

}
