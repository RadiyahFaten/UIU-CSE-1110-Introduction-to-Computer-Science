#include <stdio.h>

int main ()
{
    int a,b;
    printf("The value of X:\n");
    scanf("%d",&a);
    printf("The value of Y:\n");
    scanf("%d", &b);
    printf("Addition: %d\n", a+b);
    printf("Subtraction: %d\n", a-b);
    printf("Multiplication: %d\n", a*b);
    printf("Quotient: %d\n", a/b);
    printf("Remainder: %d", a%b);
    return 0;



}

