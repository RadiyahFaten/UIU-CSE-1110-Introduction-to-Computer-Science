#include <stdio.h>
int main()
{
    int day;
    printf("Enter input: ");
    scanf("%d", &day);
    int year = day / 360;
    int remaining_without_year = day % 360;
    int month = remaining_without_year / 30;
    int remaining_days = remaining_without_year % 30;
    printf("%d years %d months %d days", year, month, remaining_days);
    return 0;
}
