#include <stdio.h>

int main ()
{
    int x;
    printf("Enter the age: ");
    scanf("%d", &x);
    printf("My age is:%d ", x);

}
