#include <stdio.h>
#define PI 3.14
#define HEIGHT 200
int main ()
{
    printf("The value of PI: %0.2f\n", PI);
    printf ("The value of HEIGHT: %d\n", HEIGHT);
    return 0;

}
