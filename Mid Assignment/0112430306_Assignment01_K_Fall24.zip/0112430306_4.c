#include <stdio.h>

int main ()
{
    int x = 5;
    printf("The integer value: %d",x);
    float y = 3.141593;
    printf("\nThe floating point value: %f", y);
    char z = 'a';
    printf("\nThe character value: %c",z);
    return 0;
}
