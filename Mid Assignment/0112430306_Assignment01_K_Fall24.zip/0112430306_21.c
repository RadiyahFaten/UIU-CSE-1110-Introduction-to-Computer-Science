#include <stdio.h>
int main()
{
    int x, y;
    printf("Enter the value of x: ");
    scanf("%d", &x);
    printf("Enter the value of y: ");
    scanf("%d", &y);
    printf("Multiplication: %d\n", x*y);
    printf("Division: %0.2f", x/(float)y);
    return 0;
    }
